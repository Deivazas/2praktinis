package lt.viko.eif.d.vaicekauskas.gamesale.config;

import jakarta.xml.ws.*;

import javax.xml.namespace.QName;
import java.net.MalformedURLException;
import java.net.URL;

@WebServiceClient(
        name="Port",
        targetNamespace = "http://www.springframework.org/schema/web-services",
        wsdlLocation = "http://localhost:8080/soapWs/orders.wsdl"
)
public class Port extends Service {

    private final static URL Port_WSDL_LOCATION;
    private final static WebServiceException Port_EXCEPTION;
    private final static QName Port_QNAME = new QName("http://www.springframework.org/schema/web-services", "ServiceInitializeService");

    static {
        URL url = null;
        WebServiceException e = null;
        try {
            url = new URL("http://localhost:8080/soapWs/orders.wsdl");
        }catch (MalformedURLException ex){
            e = new WebServiceException(ex);
        }
        Port_WSDL_LOCATION = url;
        Port_EXCEPTION = e;
    }

    public Port(){
        super(__getWsdlLocation(), Port_QNAME);
    }

    public Port(WebServiceFeature... features){
        super(__getWsdlLocation(), Port_QNAME, features);
    }

    public Port(URL wsdlLocation){
        super(wsdlLocation, Port_QNAME);
    }

    public Port(URL wsdlLocation, WebServiceFeature... features){
        super(wsdlLocation, Port_QNAME, features);
    }

    public Port(URL wsdlLocation, QName serviceName){
        super(wsdlLocation, serviceName);
    }

    public Port(URL wsdlLocation, QName serviceName, WebServiceFeature... features){
        super(wsdlLocation, serviceName, features);
    }

    @WebEndpoint(name="ServiceInitializeSoap11")
    public ServicePort getPortSoap11(){
        return super.getPort(new QName("http://www.springframework.org/schema/web-services", "ServiceInitializeSoap11"),
                ServicePort.class);
    }

    @WebEndpoint(name = "ServiceInitializeSoap11")
    public ServicePort getPortSoap11(WebServiceFeature... features){
        return super.getPort(new QName("http://www.springframework.org/schema/web-services", "ServiceInitializeSoap11"),
                ServicePort.class, features);
    }

    private static URL __getWsdlLocation(){
        if(Port_EXCEPTION!= null){
            throw Port_EXCEPTION;
        }else{
            return Port_WSDL_LOCATION;
        }
    }
}