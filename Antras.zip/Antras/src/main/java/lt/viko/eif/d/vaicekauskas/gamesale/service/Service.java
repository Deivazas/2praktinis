package lt.viko.eif.d.vaicekauskas.gamesale.service;

public class Service {
}
