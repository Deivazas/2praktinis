package lt.viko.eif.d.vaicekauskas.gamesale.config;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebResult;
import jakarta.jws.WebService;
import jakarta.jws.soap.SOAPBinding;
import jakarta.xml.bind.annotation.XmlSeeAlso;
import lt.viko.eif.d.vaicekauskas.gamesale.generated.*;

@WebService(name = "ServiceInitialize", targetNamespace = "http://www.springframework.org/schema/web-services")
@SOAPBinding(parameterStyle = SOAPBinding.ParameterStyle.BARE)
@XmlSeeAlso({
        ObjectFactory.class
})
public interface ServicePort {

    @WebMethod
    @WebResult(name = "gameOrderResponse", targetNamespace="http://www.springframework.org/schema/web-services", partName = "gameOrderResponse")
    GameOrderResponse getGameOrder(
            @WebParam(name="gameOrderRequest", targetNamespace = "http://www.springframework.org/schema/web-services", partName = "gameOrderRequest")
            GameOrderRequest gameOrderRequest);


    @WebMethod
    @WebResult(name="getGameOrderResponse", targetNamespace = "http://www.springframework.org/schema/web-services", partName = "getGameOrderResponse")
    GameResponse getGame(
            @WebParam(name ="getGameOrderRequest", targetNamespace = "http://www.springframework.org/schema/web-services", partName = "getGameOrderRequest")
            GameRequest GameRequest);


    @WebMethod
    @WebResult(name="customerResponse", targetNamespace = "http://www.springframework.org/schema/web-services", partName = "customerResponse")
    CustomerResponse getCustomer(
            @WebParam(name="customerRequest", targetNamespace = "http://www.springframework.org/schema/web-services", partName = "customerRequest")
            CustomerRequest customerRequest);
}
