package lt.viko.eif.d.vaicekauskas.gamesale;

import lt.viko.eif.d.vaicekauskas.gamesale.config.Port;
import lt.viko.eif.d.vaicekauskas.gamesale.config.ServicePort;
import lt.viko.eif.d.vaicekauskas.gamesale.generated.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class AntrasClientApplication {

    public static void main(String[] args) {
        SpringApplication.run(AntrasClientApplication.class, args);

        Port service = new Port();
        ServicePort port = service.getPortSoap11();

        GameRequest request = new GameRequest();
        GameResponse response = port.getGame(request);

        List<Game> Games = new ArrayList<>();
        Games.addAll(response.getOrder().getGames());
        for(Game Game: Games){
            System.out.println(Game.toString());
        }

        CustomerRequest request1 = new CustomerRequest();
        request1.setId(1);
        CustomerResponse response1 = port.getCustomer(request1);
        System.out.println(response1.getCustomer().toString());

        GameOrderRequest request2 = new GameOrderRequest();
        request2.setId(1);
        GameOrderResponse response2 = port.getGameOrder(request2);
        System.out.println(response2.getOrder().toString());

    }

}
