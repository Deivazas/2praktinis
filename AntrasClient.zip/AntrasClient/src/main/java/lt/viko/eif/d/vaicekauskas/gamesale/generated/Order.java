package lt.viko.eif.d.vaicekauskas.gamesale.generated;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;

import java.util.ArrayList;
import java.util.List;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "order", propOrder = {
        "id",
        "date",
        "customers",
        "Games"
})
public class Order {

    protected int id;
    protected String date;
    @XmlElement(nillable = true)
    protected List<Customer> customers;
    @XmlElement(nillable = true)
    protected List<Game> games;


    public int getId() {
        return id;
    }

    public void setId(int value) {
        this.id = value;
    }


    public String getDate() {
        return date;
    }


    public void setDate(String value) {
        this.date = value;
    }


    public List<Customer> getCustomers() {
        if (customers == null) {
            customers = new ArrayList<Customer>();
        }
        return this.customers;
    }



    public void setCustomers(List<Customer> customers) {this.customers = customers;}

    public List<Game> getGames() {
        if (games == null) {
            games = new ArrayList<Game>();
        }
        return this.games;
    }

    public void setGames(List<Game> games){
        this.games = games;
    }

    @Override
    public String toString() {
        return String.format("Order:\n\t Date = %s\n\t" +
                        "Customers: \n\t%s" +
                        "Games:\n\t\t%s",
                this.date,
                this.customers,
                this.games,
                constructCustomerString(),
                constructGameString());
    }

    private String constructCustomerString(){
        String resultCustomer = "";
        for(Customer customer : this.customers){
            resultCustomer += customer.toString();
        }
        return resultCustomer;
    }

    private String constructGameString(){
        String resultGame = "";
        for(Game game : this.games){
            resultGame += game.toString();
        }
        return resultGame;
    }
}