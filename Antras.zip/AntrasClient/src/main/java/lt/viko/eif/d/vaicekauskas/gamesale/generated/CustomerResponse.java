package lt.viko.eif.d.vaicekauskas.gamesale.generated;

import jakarta.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "customer"
})
@XmlRootElement(name = "getCustomerResponse")
public class CustomerResponse {

    @XmlElement(required = true)
    protected Customer customer;

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer value) {
        this.customer = value;
    }

}
