package lt.viko.eif.d.vaicekauskas.gamesale.generated;

import jakarta.xml.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "order"
})
@XmlRootElement(name = "GameOrderResponse")
public class GameOrderResponse {

    @XmlElement(required = true)
    protected Order order;

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order value) {
        this.order = value;
    }

}