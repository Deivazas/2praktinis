package lt.viko.eif.d.vaicekauskas.gamesale.generated;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlType;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "game", propOrder = {
        "id",
        "gameName",
        "gameGenre",
        "year",
        "publisher",
        "price"
})
public class Game {

    protected int id;
    protected String gameName;
    protected String gameGenre;
    protected int year;
    protected String publisher;
    protected int price;

    public int getId() {
        return id;
    }

    public void setId(int value) {
        this.id = value;
    }

    public String getGameName() {
        return gameName;
    }

    public void setGameName(String value) {
        this.gameName = value;
    }


    public String getGameGenre() {
        return gameGenre;
    }


    public void setGameGenre(String value) {
        this.gameGenre = value;
    }


    public int getYear() {
        return year;
    }


    public void setYear(int value) {
        this.year = value;
    }

    public String getPublisher() {
        return publisher;
    }


    public void setPublisher(String value) {
        this.publisher = value;
    }


    public int getPrice() {
        return price;
    }

    public void setPrice(int value) {
        this.price = value;
    }

    @Override
    public String toString() {
        return String.format("\tgame:\n\t\t\t\t" + "gameName = %s\n\t\t\t\t" + "gameGenre = %s\n\t\t\t\t" +
                        "year = %s\n\t\t\t\t" + "Publisher = %s\n\t\t\t\t" + "Price = %s\n\t\t\t\t",
                this.gameName,
                this.gameGenre,
                this.year,
                this.publisher,
                this.price);
    }
}