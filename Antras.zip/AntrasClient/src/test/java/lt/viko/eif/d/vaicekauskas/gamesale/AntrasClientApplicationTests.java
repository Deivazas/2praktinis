package lt.viko.eif.d.vaicekauskas.gamesale;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AntrasClientApplicationTests {

    @Test
    void contextLoads() {
    }

}
