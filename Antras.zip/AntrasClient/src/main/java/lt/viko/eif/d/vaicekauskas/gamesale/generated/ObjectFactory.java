package lt.viko.eif.d.vaicekauskas.gamesale.generated;

import jakarta.xml.bind.annotation.XmlRegistry;


@XmlRegistry
public class ObjectFactory {


    public ObjectFactory() {
    }


    public GameOrderRequest createGameOrderRequest() {
        return new GameOrderRequest();
    }

    public GameOrderResponse createGameOrderResponse() {
        return new GameOrderResponse();
    }
    public Order createOrder() {
        return new Order();
    }

    public GameRequest createGameRequest() {
        return new GameRequest();
    }
    
    public GameResponse createGameResponse() {
        return new GameResponse();
    }
    
    public Game createGame() {
        return new Game();
    }

    public CustomerRequest createCustomerRequest() {
        return new CustomerRequest();
    }

    public CustomerResponse createCustomerResponse() {
        return new CustomerResponse();
    }

    public Customer createCustomer() {
        return new Customer();
    }

}
