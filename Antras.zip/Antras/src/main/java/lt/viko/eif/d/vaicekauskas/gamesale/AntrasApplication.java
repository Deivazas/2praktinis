package lt.viko.eif.d.vaicekauskas.gamesale;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AntrasApplication {

    public static void main(String[] args) {
        SpringApplication.run(AntrasApplication.class, args);
    }

}
