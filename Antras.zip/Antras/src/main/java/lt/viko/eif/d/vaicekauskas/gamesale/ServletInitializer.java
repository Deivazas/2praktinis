package lt.viko.eif.d.vaicekauskas.gamesale;

import jakarta.annotation.PostConstruct;
import org.springframework.schema.web_services.Game;
import org.springframework.schema.web_services.Customer;
import org.springframework.schema.web_services.Order;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ServletInitializer {

    private static final Map<Integer, Order> orders = new HashMap<>();
    private static final Map<Integer, Customer> customers = new HashMap<>();
    private static final List<Game> games = new ArrayList<>();

    @PostConstruct
    public void initialize(){

        Customer customer1 = new Customer();
        customer1.setId(1);
        customer1.setFirstName("Jhon");
        customer1.setLastName("Mattew");

        Game game1 = new Game();
        game1.setId(1);
        game1.setGameName("Squad");
        game1.setGameGenre("Shooter");
        game1.setYear(2014);
        game1.setPublisher("Eneba");
        game1.setPrice(35.99);

        Order order1 = new Order();
        order1.setId(1);
        order1.setDate("2021-05-24");
        order1.setCustomers(List.of(customer1));
        order1.setGames(List.of(game1));

        orders.put(order1.getId(), order1);
        customers.put(customer1.getId(), customer1);
        Games.add(game1);

    }

    public Order getOrders(Integer id){
        return orders.get(id);
    }

    public Customer getCustomers(Integer id){
        return customers.get(id);
    }

    public List<Game> getAllGames(){
        return Games;
    }
}
