package lt.viko.eif.d.vaicekauskas.gamesale.endpoint;

import lt.viko.eif.d.vaicekauskas.gamesale.ServletInitializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.schema.web_services.CustomerRequest;
import org.springframework.schema.web_services.CustomerResponse;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

@Endpoint
public class CustomerEnd {

    @Autowired
    private ServletInitializer customerService;

    @PayloadRoot(namespace = "http://www.springframework.org/schema/web-services",
            localPart = "getCustomerRequest")
    @ResponsePayload
    public CustomerResponse getCustomerRequest(@RequestPayload CustomerRequest request){
        CustomerResponse response = new CustomerResponse();
        response.setCustomer(customerService.getCustomers(request.getId()));

        return response;
    }

}
