package lt.viko.eif.d.vaicekauskas.gamesale.endpoint;

import lt.viko.eif.d.vaicekauskas.gamesale.ServletInitializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.schema.web_services.GameRequest;
import org.springframework.schema.web_services.GameResponse;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

@Endpoint
public class GameEnd {

    @Autowired
    private ServletInitializer GameEnd;

    @PayloadRoot(namespace = "http://www.springframework.org/schema/web-services",
            localPart = "GameRequest")
    @ResponsePayload
    public GameResponse getGames(@RequestPayload GameRequest request){
        GameResponse response = new GameResponse();
        response.getGames().addAll(gameService.getGames());

        return response;
    }
}
