package lt.viko.eif.d.vaicekauskas.gamesale.endpoint;

import lt.viko.eif.d.vaicekauskas.gamesale.ServletInitializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.schema.web_services.GameOrderRequest;
import org.springframework.schema.web_services.GameOrderResponse;

@Endpoint
public class GameOrderEnd {

    @Autowired
    private ServletInitializer gameOrderService;

    @PayloadRoot(namespace = "http://www.springframework.org/schema/web-services",
            localPart = "getGameOrderRequest")
    @ResponsePayload
    public GameOrderResponse GameOrderRequest(@RequestPayload GameOrderRequest request){
        GameOrderResponse response = new GameOrderResponse();
        response.setOrder(gameOrderService.getOrders(request.getId()));

        return response;
    }
}
